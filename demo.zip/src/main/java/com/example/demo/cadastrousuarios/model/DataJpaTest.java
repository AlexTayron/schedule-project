package com.example.demo.cadastrousuarios.model;

public @interface DataJpaTest {

}
