package com.example.demo.cadastrousuarios.model;

public @interface Test {

}
