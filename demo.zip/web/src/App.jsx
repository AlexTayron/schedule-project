// src/App.jsx

import React, { useState } from 'react';
import api from './api';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState([]);

  const handleSearch = async () => {
    try {
      const response = await api.get(`/users/${searchTerm}`);
      setUsers(response.data);
    } catch (error) {
      console.error("There was an error fetching the users!", error);
    }
  };

  return (
    <div>
      <h1>Bem-vindo!</h1>
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Buscar por nome ou email"
      />
      <button onClick={handleSearch}>Buscar</button>

      {users.length > 0 && (
        <ul>
          {users.map((user) => (
            <li key={user.id}>{user.name} - {user.email}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;
